#ifndef LOCK_H
#define LOCK_H

#include "lock_ts.h"	// Test-and-Set Lock

#include "lock_tts.h"	// Test and Test-and-Set Lock

#include "lock_mcs.h"	// MCS Lock

#include "lock_cxx.h"	// C++ Lock

#endif /* LOCK_H */
